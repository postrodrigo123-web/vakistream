VakiStream - pasta src

Conteúdo: navigation, services, store, hook, component e screens.
Copie a pasta src para a raiz do repositório vakistream.
O Supabase usa EXPO_PUBLIC_SUPABASE_URL e EXPO_PUBLIC_SUPABASE_ANON_KEY.
playlistService espera uma tabela 'playlists' com id, title, url, thumbnail, description e created_at.
