import React from "react";
import { Image, Pressable, StyleSheet, Text, View } from "react-native";
import type { PlaylistItem } from "../services/playlistService";

type Props = {
  item: PlaylistItem;
  onPress: () => void;
  onDownload?: () => void;
};

export default function MediaCard({ item, onPress, onDownload }: Props) {
  return (
    <Pressable style={styles.card} onPress={onPress}>
      {item.thumbnail ? (
        <Image source={{ uri: item.thumbnail }} style={styles.image} />
      ) : (
        <View style={[styles.image, styles.placeholder]}>
          <Text style={styles.play}>▶</Text>
        </View>
      )}
      <View style={styles.body}>
        <Text style={styles.title} numberOfLines={2}>{item.title}</Text>
        {!!item.description && (
          <Text style={styles.description} numberOfLines={2}>{item.description}</Text>
        )}
        {onDownload && (
          <Pressable style={styles.download} onPress={(e) => { e.stopPropagation(); onDownload(); }}>
            <Text style={styles.downloadText}>Baixar</Text>
          </Pressable>
        )}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#171a1f",
    borderRadius: 14,
    overflow: "hidden",
    marginBottom: 14,
  },
  image: { width: "100%", height: 190 },
  placeholder: { alignItems: "center", justifyContent: "center", backgroundColor: "#252a31" },
  play: { color: "#fff", fontSize: 34 },
  body: { padding: 14 },
  title: { color: "#fff", fontSize: 17, fontWeight: "700" },
  description: { color: "#aeb6c2", marginTop: 6 },
  download: {
    alignSelf: "flex-start",
    marginTop: 12,
    backgroundColor: "#2d6cdf",
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 9,
  },
  downloadText: { color: "#fff", fontWeight: "700" },
});
