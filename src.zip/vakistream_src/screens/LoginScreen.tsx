import React, { useEffect, useState } from "react";
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { supabase } from "../services/supabase";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../navigation/AppNavigator";

type Props = NativeStackScreenProps<RootStackParamList, "Login">;

export default function LoginScreen({ navigation }: Props) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigation.replace("Home");
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session) navigation.replace("Home");
    });

    return () => listener.subscription.unsubscribe();
  }, [navigation]);

  const login = async () => {
    if (!email || !password) {
      Alert.alert("Atenção", "Preenche o e-mail e a palavra-passe.");
      return;
    }

    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);

    if (error) Alert.alert("Erro", error.message);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.logo}>VakiStream</Text>
      <Text style={styles.subtitle}>Entra na tua conta</Text>

      <TextInput
        value={email}
        onChangeText={setEmail}
        placeholder="E-mail"
        placeholderTextColor="#737c88"
        autoCapitalize="none"
        keyboardType="email-address"
        style={styles.input}
      />
      <TextInput
        value={password}
        onChangeText={setPassword}
        placeholder="Palavra-passe"
        placeholderTextColor="#737c88"
        secureTextEntry
        style={styles.input}
      />

      <Pressable disabled={loading} onPress={login} style={styles.button}>
        <Text style={styles.buttonText}>{loading ? "A entrar..." : "Entrar"}</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0d0f12", justifyContent: "center", padding: 24 },
  logo: { color: "#fff", fontSize: 34, fontWeight: "900", textAlign: "center" },
  subtitle: { color: "#8f98a5", textAlign: "center", marginTop: 6, marginBottom: 28 },
  input: { backgroundColor: "#171a1f", color: "#fff", borderRadius: 12, paddingHorizontal: 15, paddingVertical: 14, marginBottom: 12 },
  button: { backgroundColor: "#2d6cdf", borderRadius: 12, paddingVertical: 14, alignItems: "center", marginTop: 4 },
  buttonText: { color: "#fff", fontWeight: "800", fontSize: 16 },
});
