import React, { useCallback, useEffect, useState } from "react";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../navigation/AppNavigator";
import { deleteDownload, listDownloads, DownloadedMedia } from "../services/downloadService";

type Props = NativeStackScreenProps<RootStackParamList, "Downloads">;

export default function DownloadsScreen({ navigation }: Props) {
  const [items, setItems] = useState<DownloadedMedia[]>([]);

  const load = useCallback(async () => {
    setItems(await listDownloads());
  }, []);

  useEffect(() => { load(); }, [load]);

  const remove = async (id: string) => {
    await deleteDownload(id);
    await load();
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()}><Text style={styles.back}>‹ Voltar</Text></Pressable>
        <Text style={styles.title}>Downloads</Text>
      </View>

      <FlatList
        data={items}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        ListEmptyComponent={<Text style={styles.empty}>Ainda não tens downloads.</Text>}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Pressable style={styles.info} onPress={() => navigation.navigate("Player", { url: item.localUri, title: item.title })}>
              <Text style={styles.itemTitle} numberOfLines={1}>{item.title}</Text>
              <Text style={styles.date}>{new Date(item.downloadedAt).toLocaleString()}</Text>
            </Pressable>
            <Pressable onPress={() => remove(item.id)}><Text style={styles.delete}>Apagar</Text></Pressable>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0d0f12", paddingTop: 55, paddingHorizontal: 16 },
  header: { flexDirection: "row", alignItems: "center", gap: 18, marginBottom: 20 },
  back: { color: "#7db0ff", fontSize: 16 },
  title: { color: "#fff", fontSize: 24, fontWeight: "800" },
  list: { paddingBottom: 30 },
  empty: { color: "#8f98a5", textAlign: "center", marginTop: 50 },
  item: { flexDirection: "row", alignItems: "center", backgroundColor: "#171a1f", padding: 14, borderRadius: 12, marginBottom: 10 },
  info: { flex: 1 },
  itemTitle: { color: "#fff", fontSize: 16, fontWeight: "700" },
  date: { color: "#858e9a", marginTop: 5, fontSize: 12 },
  delete: { color: "#ff6b6b", fontWeight: "700", marginLeft: 12 },
});
