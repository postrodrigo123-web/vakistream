import React, { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../navigation/AppNavigator";
import MediaCard from "../components/MediaCard";
import { getPlaylists, PlaylistItem } from "../services/playlistService";
import { downloadMedia } from "../services/downloadService";

type Props = NativeStackScreenProps<RootStackParamList, "Home">;

export default function HomeScreen({ navigation }: Props) {
  const [items, setItems] = useState<PlaylistItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    setMessage("");
    try {
      setItems(await getPlaylists());
    } catch (e: any) {
      setMessage(e?.message ?? "Não foi possível carregar os conteúdos.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleDownload = async (item: PlaylistItem) => {
    try {
      setMessage("A baixar...");
      await downloadMedia(item.id, item.title, item.url);
      setMessage("Download concluído.");
    } catch (e: any) {
      setMessage(e?.message ?? "Erro no download.");
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.brand}>VakiStream</Text>
          <Text style={styles.subtitle}>Streaming móvel</Text>
        </View>
        <Pressable onPress={() => navigation.navigate("Downloads")} style={styles.button}>
          <Text style={styles.buttonText}>Downloads</Text>
        </Pressable>
      </View>

      {message ? <Text style={styles.message}>{message}</Text> : null}

      {loading ? (
        <ActivityIndicator size="large" />
      ) : (
        <FlatList
          data={items}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          onRefresh={load}
          refreshing={loading}
          ListEmptyComponent={<Text style={styles.empty}>Nenhum conteúdo encontrado.</Text>}
          renderItem={({ item }) => (
            <MediaCard
              item={item}
              onPress={() => navigation.navigate("Player", { url: item.url, title: item.title })}
              onDownload={() => handleDownload(item)}
            />
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0d0f12", paddingTop: 55, paddingHorizontal: 16 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 },
  brand: { color: "#fff", fontSize: 27, fontWeight: "800" },
  subtitle: { color: "#8f98a5", marginTop: 2 },
  button: { backgroundColor: "#242a33", paddingHorizontal: 12, paddingVertical: 9, borderRadius: 9 },
  buttonText: { color: "#fff", fontWeight: "700" },
  list: { paddingBottom: 30 },
  message: { color: "#b8c2cf", marginBottom: 10 },
  empty: { color: "#8f98a5", textAlign: "center", marginTop: 40 },
});
