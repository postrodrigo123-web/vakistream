import React, { useEffect, useRef, useState } from "react";
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from "react-native";
import { Video, ResizeMode, AVPlaybackStatus } from "expo-av";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../navigation/AppNavigator";

type Props = NativeStackScreenProps<RootStackParamList, "Player">;

export default function PlayerScreen({ navigation, route }: Props) {
  const video = useRef<Video>(null);
  const [status, setStatus] = useState<AVPlaybackStatus | null>(null);

  useEffect(() => {
    return () => { video.current?.unloadAsync(); };
  }, []);

  const playing = status?.isLoaded ? status.isPlaying : false;

  return (
    <View style={styles.container}>
      <View style={styles.top}>
        <Pressable onPress={() => navigation.goBack()}><Text style={styles.back}>‹ Voltar</Text></Pressable>
        <Text style={styles.title} numberOfLines={1}>{route.params.title ?? "VakiStream"}</Text>
      </View>

      <Video
        ref={video}
        style={styles.video}
        source={{ uri: route.params.url }}
        useNativeControls
        resizeMode={ResizeMode.CONTAIN}
        shouldPlay
        onPlaybackStatusUpdate={setStatus}
      />

      {!status?.isLoaded && <ActivityIndicator size="large" />}
      {status?.isLoaded && (
        <Text style={styles.state}>{playing ? "A reproduzir" : "Pausado"}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#000", paddingTop: 55, paddingHorizontal: 12 },
  top: { flexDirection: "row", alignItems: "center", gap: 16, marginBottom: 14 },
  back: { color: "#7db0ff", fontSize: 16 },
  title: { color: "#fff", fontSize: 18, fontWeight: "700", flex: 1 },
  video: { width: "100%", aspectRatio: 16 / 9, backgroundColor: "#111" },
  state: { color: "#8f98a5", textAlign: "center", marginTop: 12 },
});
