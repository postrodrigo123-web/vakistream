import { create } from "zustand";

type PlayerState = {
  currentUrl: string | null;
  currentTitle: string | null;
  setCurrent: (url: string, title?: string) => void;
  clear: () => void;
};

export const usePlayerStore = create<PlayerState>((set) => ({
  currentUrl: null,
  currentTitle: null,
  setCurrent: (url, title) =>
    set({ currentUrl: url, currentTitle: title ?? "VakiStream" }),
  clear: () => set({ currentUrl: null, currentTitle: null }),
}));
