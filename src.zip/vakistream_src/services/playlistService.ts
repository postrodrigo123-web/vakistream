import { supabase } from "./supabase";

export type PlaylistItem = {
  id: string;
  title: string;
  url: string;
  thumbnail?: string | null;
  description?: string | null;
};

export async function getPlaylists(): Promise<PlaylistItem[]> {
  const { data, error } = await supabase
    .from("playlists")
    .select("id,title,url,thumbnail,description")
    .order("created_at", { ascending: false });

  if (error) throw error;
  return (data ?? []) as PlaylistItem[];
}

export async function getPlaylistById(id: string): Promise<PlaylistItem | null> {
  const { data, error } = await supabase
    .from("playlists")
    .select("id,title,url,thumbnail,description")
    .eq("id", id)
    .maybeSingle();

  if (error) throw error;
  return data as PlaylistItem | null;
}
