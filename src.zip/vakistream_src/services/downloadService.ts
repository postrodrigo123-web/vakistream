import * as FileSystem from "expo-file-system";

export type DownloadedMedia = {
  id: string;
  title: string;
  url: string;
  localUri: string;
  downloadedAt: string;
};

const INDEX_FILE = `${FileSystem.documentDirectory}vakistream-downloads.json`;
const DOWNLOAD_DIR = `${FileSystem.documentDirectory}vakistream/`;

async function ensureDirectory() {
  const info = await FileSystem.getInfoAsync(DOWNLOAD_DIR);
  if (!info.exists) {
    await FileSystem.makeDirectoryAsync(DOWNLOAD_DIR, { intermediates: true });
  }
}

async function readIndex(): Promise<DownloadedMedia[]> {
  try {
    const info = await FileSystem.getInfoAsync(INDEX_FILE);
    if (!info.exists) return [];
    const raw = await FileSystem.readAsStringAsync(INDEX_FILE);
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

async function writeIndex(items: DownloadedMedia[]) {
  await FileSystem.writeAsStringAsync(INDEX_FILE, JSON.stringify(items));
}

function safeName(value: string) {
  return value.replace(/[^a-z0-9-_]/gi, "_").slice(0, 80) || "video";
}

export async function listDownloads() {
  return readIndex();
}

export async function downloadMedia(
  id: string,
  title: string,
  url: string,
): Promise<DownloadedMedia> {
  await ensureDirectory();

  const extension = url.split("?")[0].match(/\.[a-z0-9]{2,5}$/i)?.[0] ?? ".mp4";
  const localUri = `${DOWNLOAD_DIR}${safeName(id)}-${safeName(title)}${extension}`;

  const result = await FileSystem.downloadAsync(url, localUri);

  const item: DownloadedMedia = {
    id,
    title,
    url,
    localUri: result.uri,
    downloadedAt: new Date().toISOString(),
  };

  const current = (await readIndex()).filter((x) => x.id !== id);
  current.unshift(item);
  await writeIndex(current);

  return item;
}

export async function deleteDownload(id: string) {
  const current = await readIndex();
  const item = current.find((x) => x.id === id);

  if (item) {
    try {
      await FileSystem.deleteAsync(item.localUri, { idempotent: true });
    } catch {}
  }

  await writeIndex(current.filter((x) => x.id !== id));
}
