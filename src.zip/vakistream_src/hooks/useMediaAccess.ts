import { useCallback, useState } from "react";
import * as MediaLibrary from "expo-media-library";

export function useMediaAccess() {
  const [granted, setGranted] = useState<boolean | null>(null);

  const requestAccess = useCallback(async () => {
    const result = await MediaLibrary.requestPermissionsAsync();
    const ok = result.status === "granted";
    setGranted(ok);
    return ok;
  }, []);

  return { granted, requestAccess };
}
